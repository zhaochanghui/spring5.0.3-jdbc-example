package com.zch;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class Hello {
    @RequestMapping("/hello")
    public String hello(){
        return "h";  /*
        h 是视图的名称
        dispatcher-servlet.xml 中的配置的目录要有h.jsp

        */
    }
}
